/* SPDX-License-Identifier: GPL-2.0-only OR MIT */
/*
 * Compatibility shims for building drm/imagination (mainline 6.16) against the
 * 6.6 vendor kernel. Real headers are included first so that macro shims below
 * cannot mangle their declarations.
 */
#ifndef PVR_COMPAT_H
#define PVR_COMPAT_H

#include <linux/string.h>
#include <linux/version.h>
#include <drm/drm_exec.h>
#include <drm/drm_gem_shmem_helper.h>
#include <drm/gpu_scheduler.h>

/* mainline include/linux/sizes.h - neither constant exists in 6.6 */
#ifndef SZ_64G
#define SZ_64G	_AC(0x1000000000, ULL)
#endif
#ifndef SZ_128G
#define SZ_128G	_AC(0x2000000000, ULL)
#endif

/*
 * Added to drm_gem.h after 6.6. The gpuva member it walks is byte-identical in
 * 6.6 and 6.16, so the mainline definition applies verbatim. Must be defined
 * before drm_gpuvm.h, which uses it internally.
 */
#ifndef drm_gem_for_each_gpuvm_bo
#define drm_gem_for_each_gpuvm_bo(entry__, obj__) \
	list_for_each_entry(entry__, &(obj__)->gpuva.list, list.entry.gem)
#endif

#if LINUX_VERSION_CODE < KERNEL_VERSION(6, 16, 0)
/* mainline include/linux/string.h */
static inline bool mem_is_zero(const void *s, size_t n)
{
	return !memchr_inv(s, 0, n);
}
#endif

#if LINUX_VERSION_CODE < KERNEL_VERSION(6, 15, 0)
/*
 * Renamed in 6.15 to make the locking contract explicit. Checked, not assumed:
 * the 6.12 body carries dma_resv_assert_held(), identical to 6.16's _locked
 * variant, so this is a rename and not a behaviour change. The driver does hold
 * the resv lock when it calls these, so aliasing is correct.
 */
#define drm_gem_shmem_vmap_locked drm_gem_shmem_vmap
#define drm_gem_shmem_vunmap_locked drm_gem_shmem_vunmap
#endif

#if LINUX_VERSION_CODE < KERNEL_VERSION(6, 12, 0)
/* 6.12 grew a third parameter for the initial array size. */
static inline void pvr_drm_exec_init(struct drm_exec *exec, u32 flags, unsigned nr)
{
	drm_exec_init(exec, flags);
}
#define drm_exec_init(exec, flags, nr) pvr_drm_exec_init(exec, flags, nr)
#endif

#if LINUX_VERSION_CODE < KERNEL_VERSION(6, 16, 0)
/* Added after 6.12; the 6.6 job struct has the same dependencies xarray. */
static inline bool
pvr_drm_sched_job_has_dependency(struct drm_sched_job *job, struct dma_fence *fence)
{
	struct dma_fence *f;
	unsigned long index;

	xa_for_each(&job->dependencies, index, f) {
		if (f == fence)
			return true;
	}
	return false;
}
#define drm_sched_job_has_dependency(job, fence) \
	pvr_drm_sched_job_has_dependency(job, fence)
#endif

#if LINUX_VERSION_CODE < KERNEL_VERSION(6, 16, 0)
/*
 * 6.16 moved drm_sched_init() to a struct and gave drm_sched_job_init() a
 * credits argument. Provide the 6.16 shape on top of the 6.6 calls; 6.6's third
 * drm_sched_init() parameter is the hardware submission limit, which is what
 * credit_limit means here.
 */
struct drm_sched_init_args {
	const struct drm_sched_backend_ops *ops;
	struct workqueue_struct *submit_wq;
	struct workqueue_struct *timeout_wq;
	u32 num_rqs;
	u32 credit_limit;
	unsigned int hang_limit;
	long timeout;
	atomic_t *score;
	const char *name;
	struct device *dev;
};

static inline int
pvr_drm_sched_init(struct drm_gpu_scheduler *sched,
		   const struct drm_sched_init_args *args)
{
	return drm_sched_init(sched, args->ops, args->credit_limit, args->hang_limit,
			      args->timeout, args->timeout_wq, args->score,
			      args->name, args->dev);
}
#define drm_sched_init(sched, args) pvr_drm_sched_init(sched, args)

static inline int
pvr_drm_sched_job_init(struct drm_sched_job *job, struct drm_sched_entity *entity,
		       u32 credits, void *owner)
{
	return drm_sched_job_init(job, entity, owner);
}
#define drm_sched_job_init(job, entity, credits, owner) \
	pvr_drm_sched_job_init(job, entity, credits, owner)
#endif

#endif /* PVR_COMPAT_H */
