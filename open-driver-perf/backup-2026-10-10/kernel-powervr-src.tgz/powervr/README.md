# drm/imagination (PowerVR) backport for the 6.6 A733 vendor kernel

Mainline `drm/imagination` built as a loadable module against the Radxa
`6.6.98-5-aw2511` kernel, which has no `CONFIG_DRM_POWERVR`.

## Result

    powervr.ko   0.3 MB
    vermagic=6.6.98-5-aw2511 SMP mod_unload aarch64     <- matches the running kernel
    depends=gpu-sched,drm_shmem_helper,drm_exec         <- all present on the board
    modpost: 0 errors, all 208 undefined symbols resolved

**WORKS.** The fully open stack runs on this board: open kernel driver + open
firmware + Mesa's open Vulkan driver. Verified end to end:

    physical devices: 1
    device : PowerVR B-Series BXM-4-64 MC1   (deviceID 0x36104183)
    api    : 1.2.363   driver: 26.2.99
    limits : maxComputeWorkGroupInvocations=128  maxImageDimension2D=8192
    vkCreateDevice: OK     <- exercises kernel-side context creation
    queue: OK

Full recipe:

    modprobe gpu-sched drm_exec drm_shmem_helper
    insmod powervr.ko
    systemctl stop display-manager ; pkill -x kwin_x11   # free the GPU first
    echo 1800000.gpu > /sys/bus/platform/drivers/pvrsrvkm/unbind
    echo 1800000.gpu > /sys/bus/platform/drivers/powervr/bind

    PVR_I_WANT_A_BROKEN_VULKAN_DRIVER=1 \
    VK_ICD_FILENAMES=<build>/powervr_mesa_icd.aarch64.json \
    LD_LIBRARY_PATH=<build> vulkaninfo --summary

Compiles clean, **loads**, and registers. Verified on the running board:

    modprobe gpu-sched drm_exec drm_shmem_helper   # insmod does not resolve deps
    insmod powervr.ko

    powervr               221184  0
    /sys/bus/platform/drivers/powervr/  ->  bind, module, uevent, unbind
    devices bound: 0

It registers and sits idle: nothing matches `img,img-rogue` in this board's device
tree (the node is `img,gpu`, the sunxi-BSP binding), so probe never runs and no
GPU hardware is touched. `pvrsrvkm` kept its 188 references throughout, and the
module unloaded cleanly.

Note for loading: `insmod` does not resolve module dependencies, so the three
helpers above must be loaded first or it fails with "Unknown symbol".

## How

Sources from `linux-source-6.16` (the closest Debian source with the driver; it
landed in 6.13):

    drivers/gpu/drm/imagination/    75 files
    drivers/gpu/drm/drm_gpuvm.c     2752 lines   (DRM_GPUVM is the one missing Kconfig dep)
    include/drm/drm_gpuvm.h
    include/uapi/drm/pvr_drm.h      the mainline UAPI Mesa's pvr driver speaks

The 6.6 kernel already provides everything else the Kconfig asks for: `DRM_EXEC`,
`DRM_GEM_SHMEM_HELPER`, `DRM_SCHED`.

## Changes needed

`pvr_compat.h` holds every shim, each verified against a real source tree rather
than assumed:

| gap | resolution |
|---|---|
| `mem_is_zero()` | added after 6.6; one-liner over `memchr_inv()` |
| `drm_gem_shmem_vmap_locked` / `_vunmap_locked` | renamed in 6.15. The 6.12 body carries `dma_resv_assert_held()`, identical to 6.16's `_locked` variant, so it is a rename not a behaviour change - a plain alias, and the driver does hold the lock |
| `drm_exec_init(exec, flags, nr)` | third parameter added by 6.12; wrapped to the 6.6 two-arg form |
| `drm_sched_job_has_dependency()` | added after 6.12; same `dependencies` xarray exists in 6.6, so the 6.16 body applies verbatim |
| `drm_sched_init_args` struct | 6.16 moved `drm_sched_init()` to a struct; shimmed onto the 6.6 call, mapping `credit_limit` to 6.6's hardware-submission parameter |
| `drm_sched_job_init(job, entity, credits, owner)` | credits argument added; wrapped |
| `drm_gem_for_each_gpuvm_bo()` | added after 6.6; the `gpuva` member it walks is byte-identical in 6.6 and 6.16 |
| `SZ_64G` / `SZ_128G` | absent from 6.6 `sizes.h` |
| `pvr_remove` signature | `platform_driver.remove` changed from `int` to `void` in 6.11; made version-conditional |
| `EXPORT_SYMBOL`s in `drm_gpuvm.c` | 6.6's vmlinux already exports `drm_gpuva_*`, so the module's 38 exports were stripped - it is self-contained |
| `dt_match` lacked `img,gpu` | **sysfs `bind` checks `driver_match_device` too** (`drivers/base/bus.c`), so the driver never probed. Adding the vendor compatible fixed it |
| clock names `core`/`sys` | the sunxi node names them `clk`/`clk_bus`; fallbacks added |
| missing `power-domains` | `of_count_phandle_with_args()` returns `-ENOENT` for an absent property and `pvr_power_domains_init()` passed that straight back, so probe died with `-2` and logged nothing. Absent now means zero |
| `drm_driver.date` | mainline dropped it; 6.6 still prints it, so NULL hit `BUG_ON(!value)` in `drm_copy_field` |
| `devm_pm_runtime_enable()` | double-enable (the vendor driver leaves runtime PM on) gave "Unbalanced pm_runtime_enable!" and an off-by-one refcount; now guarded |

## Test results on the open stack

Run from `bench/pvr-vulkan/` in the trixie-prep repo with
`PVR_I_WANT_A_BROKEN_VULKAN_DRIVER=1` and the generated ICD:

| test | result |
|---|---|
| `vkrender` offscreen render, per-pixel compare | **PASS** 262144/262144 correct; 30 frames at 256x256, 39 ms/frame |
| `vktest` compute, every element verified | **PASS** 4194304/4194304 correct, 2.05 GB/s (20 dispatches) |
| `glheadless` OpenGL, per-pixel compare | **PASS** 20 frames, 262144/262144 correct, 8.1 Mpix/s |
| `vkdescnon` non-uniform descriptor indexing | **PASS** (4 ok, 0 failed) |
| `vkdescidx` dynamic-offset descriptor arrays | **PASS** |
| `memtypes` image readback | works (3.18 ms for 512x512) |
| `vkbits` 8/16-bit storage | FAIL - feature absent (correctly reported) |
| `vk13` robustImageAccess | FAIL - feature absent |
| `vk16` shaderFloat16 | 7 ok, 2 failed |
| `bda` bufferDeviceAddress | FAIL - feature absent |
| `pctest` push constants | **segfault** - Mesa compiler: "Infinite opt loop! Unsupported alu instruction: unpack_64_2x32_split_x" |

So: rendering, compute and GL all execute correctly and verify pixel/element for
element. The failures are unimplemented Vulkan features being honestly reported as
absent, plus one Mesa shader-compiler crash in `pctest` (a Mesa bug, not the kernel
driver).

## A/B against the vendor driver

Same binaries, same machine, same workload; each stack bound in turn (they claim
the same platform device, so they cannot coexist). Desktop stopped first.

| test | vendor: `pvrsrvkm` + `libVK_IMG.so` | open: `powervr` + Mesa pvr | open/vendor |
|---|---|---|---|
| compute throughput | 2.75 GB/s | 2.51 GB/s | **91%** |
| compute correctness | 262144/262144 PASS | 262144/262144 PASS | equal |
| render | 0.787 ms/frame (83.2 Mpix/s) | 1.490 ms/frame (44.0 Mpix/s) | **53%** (1.9x slower) |
| render correctness | 65536/65536 PASS | 65536/65536 PASS | equal |
| GL (native) | PowerVR B-Series BXM-4-64, GLES 3.2, 1.993 ms/frame | **softpipe (CPU)** - Mesa pvr is Vulkan-only | n/a |
| faults | 0 | 0 | equal |

Small sample (5 dispatches / 3 frames); treat the ratio as indicative, not a
benchmark. Correctness is equal and both pass every pixel/element check.

**GL is the real gap.** The vendor stack has a native GL driver; the open stack
has no GL hardware path - `glheadless` silently fell back to `softpipe` (CPU).
GL on the open driver means zink (GL -> pvr Vulkan), which needs a coherent Mesa
build with zink and the pvr ICD; the system Mesa here (25.2.8) and the built Mesa
mismatch on `DRI_Mesa` version, so that is still unbuilt.

## Debugging notes that cost real time

- **`panic_on_oops=1` on this board.** Every oops panicked and rebooted before the
  trace reached disk, so the journal always ended at the Oops header. Setting it
  to 0 is what finally made traces readable.
- **The crashes were the closed driver, not this one.** The trace was
  `PhysHeapPagesClean [pvrsrvkm]` in `QSGRenderThread` - the running desktop still
  using the vendor driver after it was unbound. Free the GPU (stop sdm/kwin) before
  the swap.
- **The ICD json matters.** A hand-written one without `library_arch: "64"` and
  with the wrong `api_version` loads but reports "Found no drivers". Use the
  generated `powervr_mesa_icd.aarch64.json` with `library_path` corrected.

## What is not done

1. **Not installed or auto-loaded.** Loading is manual; the module is not in
   `/lib/modules` and not in the initramfs, so it cannot affect boot.
2. **No device-tree node.** The match now accepts the vendor `img,gpu` node, so no
   DT change is needed for this board.
3. **Desktop GL / X clients untested** against the open stack - only Vulkan, and
   only via `vulkaninfo` plus a minimal device+queue probe. No rendering workload
   has been run yet.

## Already in place on this board

- Firmware: `/lib/firmware/powervr/rogue_36.56.104.183_v1.fw` - header v3 with the
  `OPEN_SOURCE` flag, which is what mainline requires (the closed DDK file
  `rgx.fw.36.56.104.183` is v2 with closed build flags, and is not interchangeable).
  The driver builds this name from the hardware BVNC at runtime.
- Mesa: `libvulkan_powervr_mesa.so` built, and its device table carries
  `pvr_device_info_36_56_104_183`.

## Local performance changes (2026-10-10)

Patch: `~/open-perf/kernel-chain-apm.patch` (against `~/kernel-src/powervr.bak-20261010-claude`).

- `chain_frag` (bool, default Y, writable at runtime): the fragment job that follows a geometry +
  partial render pair in one submit is written to the CCCB by the geometry job and announced in the
  same combined kick, when it waits on nothing the geometry job does not already wait on. The FW then
  starts the 3D right after the partial render check instead of after a separate KCCB kick.
  FW trace, vkrender 512: TA done -> 3D kick 1540 -> 1210 units (render), 1840 -> 1300 (render+copy).
- `active_pm_latency_ms` (uint, default 10, read at FW init): was 0; the vendor driver uses 10 on
  this SoC.
- vkrender medians (ms/frame): render 512 0.550 -> 0.487, render+copy 512 0.888 -> 0.757,
  render 2048 2.37 -> 2.29, render+copy 2048 6.22 -> 5.88. CTS selections and gate unchanged.

- `fw_code_cached` (bool, default Y, read at load): firmware code and data are mapped through the
  device cache (SLC) instead of bypassing it, as the vendor driver does (FIRMWARE_CACHED |
  GPU_CACHE_INCOHERENT). Uncached, every firmware I/D-cache refill went to DRAM and each firmware
  step took ~1.5-3x the vendor's (same trace lines, side by side). Patch
  `~/open-perf/kernel-fwcode-cached.patch` (against `~/kernel-src/powervr.bak-pre-fwcached`).
  render 512: frag done 411 -> 368 us after submit; batched 512 pass 0.379 -> 0.336 ms. Tried and
  dropped: CCCB/contexts/HWRT/free list FW data through the firmware cached window or fully cached
  (no consistent gain, more coherency risk).
- The `PVRDBG` prints on per-frame ioctls (create_bo, get_bo_mmap_offset, submit_jobs, vm_map,
  vm_unmap) are `pr_debug` now (enable with dynamic debug); each pr_info also woke journald through
  kmsg. render 512 0.466 -> 0.366 ms, render+copy 512 0.826 -> 0.705 ms (performance governor).
  Patch `~/open-perf/kernel-pvrdbg-hotpath.patch`. Lifecycle prints (open, close, contexts,
  suspend/resume) are unchanged.
Installed at `/lib/modules/6.6.98-5-aw2511/extra/powervr/powervr.ko`; original kept as
`powervr.ko.orig-20261010`, the chain/APM-only build as `powervr.ko.chain-apm-20261010`
(undo: copy one back, then rebind).

## Job timeout recovery (2026-10-10)
`pvr_queue_timedout_job()` and `pvr_queue_start()` called `drm_sched_start(sched, 0)` (the 6.13+ errno
signature). On 6.6 the argument is `bool full_recovery`: 0 skipped re-adding the done callbacks and re-arming the
timeout, so after a job outlived the 500 ms timeout its pending jobs never completed and the next timeout blocked
forever in `drm_sched_stop()` (powervr-sched kworkers in D). Now `true`. Verified: `vkheavy 8192 1` (~3 s job,
10 timeouts) completes; CTS `memory.pipeline_barrier.graphics.host_write_vertex_buffer.1048576_vertex_buffer_stride_2`
under build load: 2 timeouts, Pass; no D-state. Patch: `~/open-perf/kernel-sched-start-recovery.patch`.

## Combined 3D / partial render (2026-10-10, param `combine_pr`, default Y, 0644)
When the partial-render jobs FRAG_PR command is byte-identical to the chained fragment jobs FRAG command
(Mesa builds them from the same state when no PR scratch buffer is needed), only its fence waits go to the
CCCB; the firmware uses the fragment command for partial renders, as the vendor KM does with
`bUseCombined3DAnd3DPR`. The PR jobs done fence is satisfied by the fragment jobs later timeline seqno.
A/B (Mesa fef7725, interleaved x10): render512 -4%, render+copy 512 -4%, 2048 -1..-4%. CTS 5 lists identical,
PR stress pixel-exact, weston OK. Very large PR-heavy draws (1M vertices) log one "Job timeout" (the PR job
stays pending until the fragment job ends) and recover. Patch: `~/open-perf/kernel-combine-pr.patch`.
